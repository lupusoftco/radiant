<div class="features">
	<div class="container">
		<div class="row">
			<?php
				echo $ayarlarsatir["footericerik"];
			?>	
		</div>
	</div>
		
</div>