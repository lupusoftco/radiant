<main>
    <div class="container-fluid">
        <h1 class="mt-4">Kampanya Yönetimi</h1>
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-bullhorn mr-1"></i> Kampanyalar</div>
            <form method="POST" class="sayfaform" style="display: none;">
                <input type="text" name="sayfaadi">
            </form>
            <div class="card-body">
                <div class="table-responsive">
                    test a
                </div>
            </div>
        </div>
    </div>
</main>